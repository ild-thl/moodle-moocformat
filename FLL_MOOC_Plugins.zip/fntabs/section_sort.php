<?php

// TODO:
/*
 * check capability
 * add redirect to correct chapter/week
 * what else you think you have to do ;-)
 */

require_once('../../../config.php');
global $DB, $CFG;

$sectionid = optional_param('sectionid', 0, PARAM_INT);
$courseid = optional_param('courseid', 0, PARAM_INT);
$moveup = optional_param('moveup', 0, PARAM_INT);
$movedown = optional_param('movedown', 0, PARAM_INT);
$selected_week = optional_param('selected_week', 0, PARAM_INT);

if (!$sectionid AND !$courseid) {
    redirect($CFG->wwwroot . '/my', 'Required Section-ID and Course-ID are missing', null, \core\output\notification::NOTIFY_WARNING);
}

$context = context_course::instance($courseid);
if (!has_capability('moodle/course:update', $context)) {
    $url = new moodle_url('/course/view.php', array('id' => $courseid, 'selected_week' => $selected_week));
    redirect($url, 'Sie haben nicht die erforderlichen Berechtigung zum Bearbeiten der Seite!', null, \core\output\notification::NOTIFY_ERROR);
}

rebuild_course_cache($courseid, true);

if ($sectionid) {
    $rawdata = $DB->get_record('course_sections', array('id' => $sectionid));
} else if ($courseid) {
    $rawdata = $DB->get_record('course_sections', array('course' => $courseid));
}

$sequence = explode(',', $rawdata->sequence);

if ($movedown) {
    $value_new = $movedown;
    // Get the current key for the value to move
    $key_current = array_search($movedown, $sequence);
    // Get the new key for the value to move
    $key_new = $key_current + 1;
    // Get the old value which will be switched to $key_current
    $value_old = $sequence[$key_new];

    $sequence[$key_current] = $value_old;
    $sequence[$key_new] = $value_new;

    $sequence = implode(',', $sequence);

    $data->sequence = $sequence;
    $data->id = $sectionid;

    if( $DB->update_record('course_sections', $data)) {
        $url = new moodle_url('/course/view.php', array('id' => $courseid, 'selected_week' => $selected_week));
        redirect($url, 'Die Reihenfolge wurde erfolgreich geändert', null, \core\output\notification::NOTIFY_SUCCESS);
    } else {
        echo "NOPE";
    }

} else if ($moveup) {
    $value_new = $moveup;
    // Get the current key for the value to move
    $key_current = array_search($moveup, $sequence);
    // Get the new key for the value to move
    $key_new = $key_current - 1;
    // Get the old value which will be switched to $key_current
    $value_old = $sequence[$key_new];

    $sequence[$key_current] = $value_old;
    $sequence[$key_new] = $value_new;

    $sequence = implode(',', $sequence);

    $data->sequence = $sequence;
    $data->id = $sectionid;

    if( $DB->update_record('course_sections', $data)) {
        $url = new moodle_url('/course/view.php', array('id' => $courseid, 'selected_week' => $selected_week));
        redirect($url, 'Die Reihenfolge wurde erfolgreich geändert', null, \core\output\notification::NOTIFY_SUCCESS);
    } else {
        echo "NOPE";
    }

}
