MoodleFN - Tabs Course Format (2.5)
============================================

Locate the plugin manual here for more information about this plugin: http://moodlefn.com/docs/  

============================================

- Name: Tabs Format
- Type: Course Format
- Moodle version required: 2.5
- Support and Feedback: www.moodlefn.knet.ca 
- List all MoodleFN Plugins: https://moodle.org/plugins/browse.php?list=contributor&id=13267

