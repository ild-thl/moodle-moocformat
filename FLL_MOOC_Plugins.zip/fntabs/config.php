<?php
// deafult block on course page
    $format['defaultblocks'] = ':search_forums,news_items,calendar_upcoming,recent_activity';

