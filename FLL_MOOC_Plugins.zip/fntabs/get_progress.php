﻿<?php
header('Content-Type: text/html; charset=utf-8'); // sorgt für die korrekte Kodierung
header('Cache-Control: must-revalidate, pre-check=0, no-store, no-cache, max-age=0, post-check=0'); // ist mal wieder wichtig wegen IE
	
	require_once('../../../config.php');
	global $DB, $USER, $CFG;
	
	$sectionid = optional_param('sectionid', 0, PARAM_INT);
	$userid = optional_param('userid', 0, PARAM_INT);
	$courseid = optional_param('courseid', 0, PARAM_INT);
	
	if ($userid == $USER->id) {
		
		if (!$module = $DB->get_record('modules', array('name' => 'lti'))) {
			return -1;
		}
		$course_modules = $DB->get_records('course_modules', array('section' => $sectionid, 'course' => $courseid, 'module' => $module->id));
		
		$count = count($course_modules);
		if ($count == 0) {
			return -1;
		}
		$percentage = 0;
		foreach ($course_modules as $modu) {
			//if ($modu->name == 'lti') {
				$submissions = $DB->get_records('lti_submission', array('userid' => $USER->id, 'ltiid' => $modu->instance));
				$gradepercent = 0;
				foreach ($submissions as $submission) {
					if ($submission->gradepercent > $gradepercent) {
						$gradepercent = $submission->gradepercent;
					}
				}
				$percentage += $gradepercent / $count;
			//}
		}
		echo $sectionid.','.round($percentage);
	}
	else {
		echo 0;
	}
?>