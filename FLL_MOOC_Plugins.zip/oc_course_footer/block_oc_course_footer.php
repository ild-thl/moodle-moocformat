<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

class block_oc_course_footer extends block_base {

    public function init() {
        global $PAGE;
        $this->title = get_string('pluginname', 'block_oc_course_footer');
    }

    public function instance_allow_multiple() {
        return true;
    }

    public function has_config() {
        return false;
    }

    public function instance_allow_config() {
        return true;
    }

    public function applicable_formats() {
        return array(
            'all' => true
        );
    }

    public function specialization() {
        $this->title = '';
    }

    public function get_content() {
        global $USER, $PAGE, $CFG, $SESSION, $COURSE;

        if ($this->content !== null) {
            return $this->content;
        }
        $content = '';

        // nur anzeigen, wenn wir in der Kursansicht sind
        $exploded = explode('?', $PAGE->url->out(false));
        //if (strpos($exploded[0], '/course/') !== false) {
        if ($PAGE->pagelayout == 'course') {
            $courseid = optional_param('id', $COURSE->id, PARAM_INT);
            $chapter = optional_param('chapter', -1, PARAM_INT);
            $selected_week = optional_param('selected_week', -1, PARAM_INT);
			
			// >>> oncampus sprint
			if ($chapter >= 0) {
				set_user_preference('block_oc_mooc_nav_last_chapter_'.$courseid, $chapter, $USER->id);
			}
			if ($chapter == -1) {
				$chapter = get_user_preferences('block_oc_mooc_nav_last_chapter_'.$courseid, 0, $USER->id);
			}
			if ($selected_week > 0) {
				set_user_preference('block_oc_mooc_nav_last_week_'.$courseid, $selected_week, $USER->id);
			}
			if ($selected_week == -1) {
				$selected_week = get_user_preferences('block_oc_mooc_nav_last_week_'.$courseid, 1, $USER->id);
			}
			// <<< oncampus sprint

            $lection = $selected_week;
            if ($lection >= 1000) {
                $lection = $lection / 1000;
            }
            $chpt = $this->get_chapter_for_lection($lection, $courseid);
			/*
			Array
			(
				[number] =&gt; 1
				[first_lection] =&gt; 3
				[name] =&gt; Kapitel 2
				[lections] =&gt; 5
				[enabled] =&gt; false
				[img] =&gt; ichmooc-0b.png
			)
			*/

            $oc_prev_week = $selected_week - 1;
            if ($oc_prev_week >= 999) {
                $oc_prev_week = $SESSION->G8_selected_week[$courseid] - 1;
            }
            $oc_next_week = $selected_week + 1;
            if ($oc_next_week >= 1000) {
                $oc_next_week = $SESSION->G8_selected_week[$courseid] + 1;
            }

            /*
            $content = 'I am the footer!<br />'.
                        'chapter: '.$chapter.'<br />'.
                        'selected_week: '.$selected_week.'<br />'.
                        'oc_prev_week: '.$oc_prev_week.'<br />'.
                        'oc_next_week: '.$oc_next_week.'<br /><br />'.
                        'first_lection: '.$chpt['first_lection'].'<br />'.
                        'last_lection: '.($chpt['first_lection'] + $chpt['lections']).'<br />'.
                        'lections: '.$chpt['lections'].'<br />'.
                        'name: '.$chpt['name'].'<br /><br />'.
                        'G8_selected_week: '.$SESSION->G8_selected_week[$courseid].'<br />'.
                        'tablow: '.$SESSION->FN_tablow[$courseid].'<br />'.
                        'tabhigh: '.$SESSION->FN_tabhigh[$courseid].'<br />'.
                        'end<br />';
            */
            //print_object($SESSION);die();
			// >>> changes by oncampus sprint
			$new_chapter = $chapter;
			$chpt_count = count($this->get_chapters($courseid));
            if ($oc_next_week >= ($chpt['first_lection'] + $chpt['lections']) and $chapter == $chpt_count - 1) {
                $next_div = html_writer::tag('div', '<p>' . get_string('next', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-nextlection-inactive'));
            } else {
				$next_available = true;
				if ($oc_next_week >= ($chpt['first_lection'] + $chpt['lections'])) {
					// prüfen ob new_chapter == false oder hidden und wenn nötig bzw. möglich überspringen
					$direction = 1;
					if ($next_available = $this->get_next_available_chapter($chapter, $direction, $courseid)) {
						$new_chapter = $next_available->chapter;
						$oc_next_week = $next_available->week;
					}
					else {
						$next_div = html_writer::tag('div', '<p>' . get_string('next', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-nextlection-inactive'));
					}
				}
				if ($next_available != false) {
					$next_url = new moodle_url('/course/view.php', array('id' => $courseid, 'chapter' => $new_chapter, 'selected_week' => $oc_next_week));
					$next_link = html_writer::link($next_url, '<p>' . get_string('next', 'block_oc_course_footer') . '</p>', array('id' => 'oc-btn-nextlection'));
					$next_div = html_writer::tag('div', $next_link, array('id' => 'oc-div-nextlection'));
				}
            }
			$new_chapter = $chapter;
            if ($oc_prev_week < $chpt['first_lection'] and $chapter <= 0) {
                $previous_div = html_writer::tag('div', '<p>' . get_string('previous', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-prevlection-inactive'));
            } else {
				$next_available = true;
				if ($oc_prev_week < $chpt['first_lection']) {
					//$new_chapter = $chapter - 1;
					// prüfen ob new_chapter == false oder hidden und wenn nötig bzw. möglich überspringen
					$direction = -1;
					if ($next_available = $this->get_next_available_chapter($chapter, $direction, $courseid)) {
						$new_chapter = $next_available->chapter;
						$oc_prev_week = $next_available->week;
					}
					else {
						$previous_div = html_writer::tag('div', '<p>' . get_string('previous', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-prevlection-inactive'));
					}
				}
				if ($next_available != false) {
					$previous_url = new moodle_url('/course/view.php', array('id' => $courseid, 'chapter' => $new_chapter, 'selected_week' => $oc_prev_week));
					$previous_link = html_writer::link($previous_url, '<p>' . get_string('previous', 'block_oc_course_footer') . '</p>', array('id' => 'oc-btn-prevlection'));
					$previous_div = html_writer::tag('div', $previous_link, array('id' => 'oc-div-prevlection'));
				}
            }

            $up_url = new moodle_url('#anfang');
            $up_link = html_writer::link($up_url, '<p>' . get_string('up', 'block_oc_course_footer') . '</p>', array('id' => 'oc-btn-nextlection'));
            $up_div = html_writer::tag('div', $up_link, array('id' => 'oc-div-up'));

            $clear_div = html_writer::tag('div', '', array('style' => 'clear:both;'));

            if (isset($SESSION->lang) and $SESSION->lang == 'ar') {
				$new_chapter = $chapter;
                if ($oc_next_week >= ($chpt['first_lection'] + $chpt['lections']) and $chapter == $chpt_count - 1) {
                    $next_div = html_writer::tag('div', '<p>' . get_string('next', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-prevlection-inactive'));
                } else {
					$next_available = true;
					if ($oc_next_week >= ($chpt['first_lection'] + $chpt['lections'])) {
						// TODO prüfen ob new_chapter == false oder hidden und wenn nötig bzw. möglich überspringen
						$direction = 1;
						if ($next_available = $this->get_next_available_chapter($chapter, $direction, $courseid)) {
							$new_chapter = $next_available->chapter;
							$oc_next_week = $next_available->week;
						}
						else {
							$next_div = html_writer::tag('div', '<p>' . get_string('next', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-prevlection-inactive'));
						}
					}
					if ($next_available != false) {
						$next_url = new moodle_url('/course/view.php', array('id' => $courseid, 'chapter' => $new_chapter, 'selected_week' => $oc_next_week));
						$next_link = html_writer::link($next_url, '<p>' . get_string('next', 'block_oc_course_footer') . '</p>', array('id' => 'oc-btn-prevlection'));
						$next_div = html_writer::tag('div', $next_link, array('id' => 'oc-div-prevlection'));
					}
				}
				$new_chapter = $chapter;
                if ($oc_prev_week < $chpt['first_lection'] and $chapter <= 0) {
                    $previous_div = html_writer::tag('div', '<p>' . get_string('previous', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-nextlection-inactive'));
                } else {
					$next_available = true;
					if ($oc_prev_week < $chpt['first_lection']) {
						//$new_chapter = $chapter - 1;
						// prüfen ob new_chapter == false oder hidden und wenn nötig bzw. möglich überspringen
						$direction = -1;
						if ($next_available = $this->get_next_available_chapter($chapter, $direction, $courseid)) {
							$new_chapter = $next_available->chapter;
							$oc_prev_week = $next_available->week;
						}
						else {
							$previous_div = html_writer::tag('div', '<p>' . get_string('previous', 'block_oc_course_footer') . '</p>', array('id' => 'oc-div-nextlection-inactive'));
						}
					}
					if ($next_available != false) {
						$previous_url = new moodle_url('/course/view.php', array('id' => $courseid, 'chapter' => $new_chapter, 'selected_week' => $oc_prev_week));
						$previous_link = html_writer::link($previous_url, '<p>' . get_string('previous', 'block_oc_course_footer') . '</p>', array('id' => 'oc-btn-nextlection'));
						$previous_div = html_writer::tag('div', $previous_link, array('id' => 'oc-div-nextlection'));
					}
                }
                $course_footer_div = html_writer::tag('div', $next_div . $up_div . $previous_div . $clear_div, array('id' => 'oc-div-footerlinks'));
				$course_footer_div = html_writer::tag('div', $previous_div . $up_div . $next_div . $clear_div, array('id' => 'oc-div-footerlinks'));
            } else {
                $course_footer_div = html_writer::tag('div', $previous_div . $up_div . $next_div . $clear_div, array('id' => 'oc-div-footerlinks'));
            }

            $content .= html_writer::tag('div', $course_footer_div, array('id' => 'oc-div-footerlinks-outer'));
			// <<< changes by oncampus sprint
        }

        $this->content = new stdClass();
        $this->content->text = $content;

        return $this->content;
    }
	
	function get_next_available_chapter($current_chapter, $direction, $courseid) {
		// $direction = 1; -1;
		$chapters = $this->get_chapters($courseid);
		$chptcount = count($chapters);
		while ($current_chapter < $chptcount and $current_chapter >= 0) {
			$current_chapter = $current_chapter + $direction;
			$enabled = $chapters[$current_chapter]['enabled'];
			//print_object($chapters[$current_chapter]);
			if ($enabled == 'true')  {
				$next_available = new stdClass();
				$next_available->chapter = $current_chapter;
				if ($direction == 1) {
					$next_available->week = $chapters[$current_chapter]['first_lection'];
				}
				else {
					$next_available->week = $chapters[$current_chapter]['first_lection'] + $chapters[$current_chapter]['lections'] - 1;
				}
				
				return $next_available;
			}
		}
		return false;
	}

    function get_chapters($courseid) {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/lib/blocklib.php');

        $coursecontext = context_course::instance($courseid);
        $blockrecord = $DB->get_record('block_instances', array('blockname' => 'oc_mooc_nav', 'parentcontextid' => $coursecontext->id), '*', MUST_EXIST);
        $blockinstance = block_instance('oc_mooc_nav', $blockrecord);
        $chapter_configtext = $blockinstance->config->chapter_configtext;

        $lines = preg_split("/[\r\n]+/", trim($chapter_configtext));
        $chapters = array();
        $number = 0;
        $first = 1;
        foreach ($lines as $line) {
            $elements = explode(';', $line);
            $chapter = array();
            $chapter['number'] = $number;
            $number++;
            $chapter['first_lection'] = $first;
            foreach ($elements as $element) {
                $ex = explode('=', $element);

                if (isset($ex[1])) {
                    $chapter[$ex[0]] = $ex[1];
                }
            }
            $first += $chapter['lections'];
            $chapters[] = $chapter;
        }
        return $chapters;
    }

    function get_chapter_for_lection($lection, $courseid) {
        global $CFG;
        $sections = 0;
        $chapters = $this->get_chapters($courseid);
        foreach ($chapters as $chapter) {
            $sections = $sections + $chapter['lections'];
            if ($sections >= $lection) {
                return $chapter;
            }
        }
        return false;
    }
}
