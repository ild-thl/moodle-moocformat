<?php
/**
 * Online Users Map block - reworking of the standard Moodle online users
 * block, but this displays the users on a Google map - using the location
 * given in the Moodle profile.
 * @author Alex Little
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package block_online_users_map
 */

include_once($CFG->dirroot . '/blocks/online_users_map/lib.php');

class block_online_users_map extends block_base {

    function init() {
        $this->title = get_string('title', 'block_online_users_map');
    }

    function instance_allow_config() {
        return true;
    }

    function has_config() {
        return true;
    }

    function get_content() {
        global $USER, $CFG, $COURSE, $PAGE;

        if ($this->content !== NULL) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';

        if (empty($this->instance)) {
            return $this->content;
        }

        //Calculate minutes
        //$minutes  = floor(getTimeToShowUsers()/60);

        //$this->content->text = "<div class=\"info\">(".get_string("periodnminutes","block_online_users_map",$minutes).")</div><br />";

        $oc_descr = html_writer::tag('div', get_string('profile_city_descr', 'block_online_users_map'));
        $this->content->text .= html_writer::tag('div', $oc_descr, array('style' => 'width:100%; text-align:center;'));

        if ($CFG->block_online_users_map_type == 'osm') {
            $this->content->text .= get_html_osmmap();
        } else {
            $local_centre_lat = 53.869;
            $local_centre_lng = 10.687;
            $local_init_zoom = 5;
            if (isset($this->config->local_centre_lat)) {
                $local_centre_lat = $this->config->local_centre_lat;
            }
            if (isset($this->config->local_centre_lng)) {
                $local_centre_lng = $this->config->local_centre_lng;
            }
            if (isset($this->config->local_init_zoom)) {
                $local_init_zoom = $this->config->local_init_zoom;
            }
            $this->content->text .= get_html_googlemap($COURSE->id, $local_centre_lat, $local_centre_lng, $local_init_zoom);
        }

        // nur in oncampus custom Teilnehmer�bersicht anzeigen
        if (strpos($PAGE->url->out(false), '/blocks/oc_mooc_nav/users.php') === false and $this->config->onlyusers == 1) {
            $this->content->text = '';
            $this->title = '';
        }
        //$this->content->text .= $this->config->onlyusers;
        // if ($USER->username == 'riegerj') {
        // $this->content->text .= '*'.$this->config->local_centre_lng;
        // }
        return $this->content;
    }

    function cron() {
        update_users_locations();
        return true;
    }

    function preferred_width() {
        return 210;
    }

    /*
    public function specialization() {
        if (!empty($this->config->title)) {
            $this->title = $this->config->title;
        } else {
            $this->config->title = get_string('pluginname', 'block_online_users_map');
        }
    }*/
}

?>
